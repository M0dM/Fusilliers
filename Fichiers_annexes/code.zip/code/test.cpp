#include "automata.h"


Regle initRules(char * fileName) {
  fstream file(fileName, ios::in);

  if (file.is_open()) {
    // 5 �tats + l'�tat "bord"
    unsigned n = 5 + 1;

    Regle rules = new unsigned[n * n * n];

    unsigned value;
    for(unsigned i = 0; i < n * n * n; i++) {
      file >> value;
      rules[i] = value;
    }

    return rules;
  } else
    cerr << "Impossible d'ouvrir " << fileName << endl;
}

int main(int argc, char **argv) {
  // nombre d'�tats de l'automate cellulaire
  int nbStates = 5;

  // Nombre maximale de fusiliers (taille maximale du r�seau)
  unsigned int sizeMax = 20;

  // d�claration de l'automate cellulaire
  Automata automate(sizeMax);

  // initialise l'automate � partir d'un fichier
  char str[256];
  sprintf(str, "%s.dat", argv[1]);

  Regle rules = initRules(str);

  // calcul de la performance de rules dans un automate de taille maximale 20
  cout << automate.f(rules, 20) << endl;
  
  unsigned nFire ;

  for(unsigned i = 2; i <= sizeMax; i++) {
    // �volution de l'automate avec la r�gle rule sur un r�seau de longueur i
    nFire = automate.evol(rules, i);

    // affichage du nombre de fusiliers ayant tir�
    cout << "longueur " << i << " : " << nFire << endl;

    // affiche la dynamique dans un fichier au format svg
    sprintf(str, "svg/%s_%d.svg", argv[1], i);
    automate.print(i, 2 * i - 2, str);
  } 

}
